import 'package:flutter/cupertino.dart';

class Colors{
  const Colors();

  static const Color mainColor = const Color(0XFF151C26);
  static const Color secondColor = const Color(0XFFF4C10F);
  static const Color titleColor = const Color(0XFF5A6068);
}